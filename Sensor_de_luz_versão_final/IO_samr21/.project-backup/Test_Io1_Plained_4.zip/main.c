#include <atmel_start.h>
#include <stdio.h>

uint8_t lightSensorValue = 0;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	
	char message[15];

	/* Replace with your application code */
	while (1) {
		gpio_toggle_pin_level(LED);
		//delay_ms(50);
		adc_sync_read_channel(&Light_sensor_ADC, 0, lightSensorValue, 1);
		sprintf(message, "Sensor de Luz: %d", lightSensorValue);
		printf(message);
		delay_us(20);
	}
}


