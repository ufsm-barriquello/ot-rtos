#include <atmel_start.h>
#include <stdio.h>

volatile bool conversion_done = false;

static void convert_cb_Light_sensor_ADC(const struct adc_async_descriptor *const descr, const uint8_t channel)
{
	conversion_done = true;
}

/**
 * Example of using Light_sensor_ADC to generate waveform.
 */
void Light_sensor_init(void)
{
	adc_async_register_callback(&Light_sensor_ADC, 0, ADC_ASYNC_CONVERT_CB, convert_cb_Light_sensor_ADC);
	adc_async_enable_channel(&Light_sensor_ADC, 0);
	adc_async_start_conversion(&Light_sensor_ADC);
}

uint8_t GET_light_sensor(void){
	uint8_t lightSensorValue;
	
	adc_async_start_conversion(&Light_sensor_ADC);
	while(!conversion_done){}
	adc_async_read_channel(&Light_sensor_ADC, 0, &lightSensorValue, 1);
	
	return lightSensorValue;
}

void SET_IO1X_LED_ON(void){
	gpio_set_pin_level(LED, true);
}

void SET_IO1X_LED_OFF(void){
	gpio_set_pin_level(LED, false);
}

uint8_t light_sensor;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	char message[15];
	
	Light_sensor_init();
	

	/* Replace with your application code */
	while (1) {
		SET_IO1X_LED_ON();
		
		light_sensor = GET_light_sensor();
		io_write(&USART_debug, &light_sensor, 1);
		//delay_ms(50);
		//sprintf(message, "Sensor de Luz: %d\r\n", light_sensor);
		//printf(message);
		delay_ms(20);
		SET_IO1X_LED_OFF();
		delay_ms(20);
	}
}




