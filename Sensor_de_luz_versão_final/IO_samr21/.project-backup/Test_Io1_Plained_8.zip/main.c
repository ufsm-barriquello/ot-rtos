/**
 * C�digo de teste dos sensores 
 * 
 * Desenvolvimento atual por Guilherme Ribeiro Silveira
 *
 * Link do relat�rio com os calculos utilizados neste c�digo
 * https://docs.google.com/document/d/14jGzlbBa0Ey1IuW73ailFBDOAaCUMx8I5gUdWG36onQ/edit?usp=sharing
 *
 */
 
#include <atmel_start.h>
#include <stdio.h>

#define VCC_TARGET 3.3 // Tens�o VCC da placa de R21 usada como referencia 

volatile bool conversion_done = false;
struct io_descriptor* USART_debug_io;

/** 
 * Faz a convers�o anal�gico digital do sensor de luz e avisa quando terminar 
 */
static void convert_cb_Light_sensor_ADC(const struct adc_async_descriptor *const descr, const uint8_t channel)
{
	conversion_done = true;
}

/**
 * Inicializa o conversor AD para o sensor de luz
 */
void Light_sensor_init(void)
{
	adc_async_register_callback(&Light_sensor_ADC, 0, ADC_ASYNC_CONVERT_CB, convert_cb_Light_sensor_ADC);
	adc_async_enable_channel(&Light_sensor_ADC, 0);
	adc_async_start_conversion(&Light_sensor_ADC);
}

/**
 * Inicializa a UART usada como debug do programa
 * Pode ser usada para printf
 */
void USART_dbg_init(void){
	usart_sync_get_io_descriptor(&USART_debug, &USART_debug_io);
}

/**
 * Escreve 1 byte na UART de debug
 */
void UART_write_byte(uint8_t byte_to_send){
	io_write(USART_debug_io, &byte_to_send, 1);
}

/**
 * Le o valor digital do sensor de luz ap�s passar pelo ADC e calcula e entrega a iluminancia com base nas caracteristicas el�tricas do sensor
 */
float GET_light_sensor(void){
	uint8_t lightSensorValue;
	float voltageSensor;
	float iluminance;
	
	/* Faz a convers�o AD do sensor de luz*/
	adc_async_start_conversion(&Light_sensor_ADC);
	while(!conversion_done){}
	adc_async_read_channel(&Light_sensor_ADC, 0, &lightSensorValue, 1);
	
	/* Faz a defini��o dos valores de tens�o lidos do sensor a partir dos dados quantizados do ADC*/
	voltageSensor = lightSensorValue * VCC_TARGET / 255;
	
	/* Calcula a iluminancia com base na corrente do resistor de coletor do fototransistor e na rela��o entre lux e corrente*/
	iluminance = (VCC_TARGET - voltageSensor) * 200;
	
	return iluminance;
}

/**
 * Liga o LED da placa de expans�o IO1X
 */
void SET_IO1X_LED_ON(void){
	gpio_set_pin_level(LED, true);
}

/**
 * Desliga o LED da placa de expans�o IO1X
 */
void SET_IO1X_LED_OFF(void){
	gpio_set_pin_level(LED, false);
}

/**
 * Converte um n�mero float em string com a precis�o informada
 * � usada para poder printar valor float em tela usando o sprintf
 * O compilador usado n�o aceita float no sprintf
 */
void floatToString(float num, char* str, int precision) {
	int i = 0;

	// Extract the integral part
	int integralPart = (int)num;

	// Convert the integral part to string
	do {
		str[i++] = integralPart % 10 + '0';
		integralPart /= 10;
	} while (integralPart > 0);

	// Reverse the integral part string
	int j;
	int len = i;
	for (j = 0; j < len / 2; j++) {
		char temp = str[j];
		str[j] = str[len - j - 1];
		str[len - j - 1] = temp;
	}

	// Add decimal point
	str[i++] = '.';

	// Extract the fractional part
	float fractionalPart = num - (int)num;

	// Convert the fractional part to string
	int k;
	for (k = 0; k < precision; k++) {
		fractionalPart *= 10;
		int digit = (int)fractionalPart;
		str[i++] = digit + '0';
		fractionalPart -= digit;
	}

	// Add null-terminating character
	str[i] = '\0';
}

float light_sensor; // Iluminancia calculado a partir do sensor de luz

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	Light_sensor_init();
	USART_dbg_init();
	
	char message[15];
	char iluminance_str[10];

	while (1) {
		/* Usa e envia para a serial a iluminancia calculada*/		
		light_sensor = GET_light_sensor();
		floatToString(light_sensor, iluminance_str, 4);
		
		//UART_write_byte(light_sensor);
		//delay_ms(50);
		
		sprintf(message, "Sensor de Luz: %s\r\n", iluminance_str);
		printf(message);
		
		/* Liga e desliga o LED da placa de expans�o*/
		delay_ms(20);
		SET_IO1X_LED_OFF();
		delay_ms(20);
	}
}




