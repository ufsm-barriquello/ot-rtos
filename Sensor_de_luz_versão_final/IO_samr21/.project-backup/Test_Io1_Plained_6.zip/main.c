#include <atmel_start.h>
#include <stdio.h>

uint8_t lightSensorValue;
volatile bool conversion_done = false;

static void convert_cb_Light_sensor_ADC(const struct adc_async_descriptor *const descr, const uint8_t channel)
{
	conversion_done = true;
}

/**
 * Example of using Light_sensor_ADC to generate waveform.
 */
void ADC_Light_sensor_init(void)
{
	adc_async_register_callback(&Light_sensor_ADC, 0, ADC_ASYNC_CONVERT_CB, convert_cb_Light_sensor_ADC);
	adc_async_enable_channel(&Light_sensor_ADC, 0);
	adc_async_start_conversion(&Light_sensor_ADC);
}

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	char message[15];
	
	ADC_Light_sensor_init();
	

	/* Replace with your application code */
	while (1) {
		gpio_toggle_pin_level(LED);
		
		adc_async_start_conversion(&Light_sensor_ADC);
		while(!conversion_done){}
			
		adc_async_read_channel(&Light_sensor_ADC, 0, &lightSensorValue, 1);
		//delay_ms(50);
		sprintf(message, "Sensor de Luz: %d\r\n", lightSensorValue);
		printf(message);
		delay_us(20);
	}
}




