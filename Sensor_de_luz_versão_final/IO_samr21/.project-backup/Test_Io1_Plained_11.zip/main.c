/**
 * C�digo de teste dos sensores 
 * 
 * Desenvolvimento atual por Guilherme Ribeiro Silveira
 *
 * Link do relat�rio com os calculos utilizados neste c�digo
 * https://docs.google.com/document/d/14jGzlbBa0Ey1IuW73ailFBDOAaCUMx8I5gUdWG36onQ/edit?usp=sharing
 *
 */
 
#include <atmel_start.h>
#include <stdio.h>
#include <at30tse75x.h>
#include <temperature_sensor.h>
#include <at30tse75x_config.h>
#include <temperature_sensor_main.h>
#include <IO1X_Plained_drivers.h> // Inclui os arquivos de fun��o dos sensores da placa IO1X Plained

#define CONF_AT30TSE75X_RESOLUTION 2



struct io_descriptor *I2C_temperature_io;
struct temperature_sensor *AT30TSE75X;

static struct at30tse75x AT30TSE75X_descr;


float GET_temperature_sensor(void){
	uint8_t temp = 0;
	io_read(I2C_temperature_io, temp, 1);
	return temp;
}

float light_sensor; // Iluminancia calculado a partir do sensor de luz
uint8_t temperature;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	Sensors_init();
	temperature_sensors_init();
	
	char message[15];
	char iluminance_str[10];
	char temperature_str[10];

	while (1) {
		/* Usa e envia para a serial a iluminancia calculada*/		
		light_sensor = GET_light_sensor();
		
		floatToString(light_sensor, iluminance_str, 4);
		
		//UART_write_byte(light_sensor);
		//delay_ms(50);
		
		temperature = (uint16_t)temperature_sensor_read(AT30TSE75X);
		// temperature = 0;
		
		/*sprintf(message, "Sensor de Luz: %s\r\n", iluminance_str);
		printf(message);*/
		
		sprintf(message, "Sensor de temperatura: %d\r\n", temperature);
		printf(message);
		
		/* Liga e desliga o LED da placa de expans�o*/
		SET_IO1X_LED_ON();
		delay_ms(20);
		SET_IO1X_LED_OFF();
		delay_ms(20);
	}
}




