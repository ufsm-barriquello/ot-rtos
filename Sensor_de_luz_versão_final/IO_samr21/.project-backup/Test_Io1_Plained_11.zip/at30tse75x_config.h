/* Auto-generated config file at30tse75x_config.h */
#ifndef AT30TSE75X_CONFIG_H
#define AT30TSE75X_CONFIG_H

// <<< Use Configuration Wizard in Context Menu >>>

//<o>Resolution
//<0=>9-bits
//<1=>10 bits
//<2=>11-bits
//<3=>12-bits
//<i>This sets the resolution of temperature measurement
//<id>conf_resolution
#ifndef CONF_AT30TSE75X_RESOLUTION
#define CONF_AT30TSE75X_RESOLUTION 2
#endif

// <<< end of configuration section >>>

#endif // AT30TSE75X_CONFIG_H
